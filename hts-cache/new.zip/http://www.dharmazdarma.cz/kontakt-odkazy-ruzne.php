<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=windows-1250">
<meta name="description" content="Dharma Zdarma: vyd�v�me a distribujeme knihy o Buddhov� u�en� zdarma.">
<meta name="keywords" content="Buddhismus, knihy, zdarma, kontakt">

<title>Kontakt, Dharma zdarma</title>
<link rel="stylesheet" type="text/css" href="style-main.css"> 

 
  <style>
      
      a.kontakt {color: white; font-weight: bold}
      a.kontakt:hover  {background-position: 0px}
      
      a.kontaktbocni { top: 130px; left: 0px; background-image: none; width:120px;
                      font-weight: bold; color: white; } 
      a.kontakt-napiste  { top: 150px; left: 0px; background-image: none; width:120px; font-size: 13px}
      a.kontakt-odkazy {top: 170px; left: -5px; background-image: none; width:140px; font-size: 13px}
      a.kontakt-odkazy-ruzne {top: 190px; left: 0px; background-image: none; width:120px; font-size: 13px}
      
      h3 {text-decoration: overline; text-align: center; font-size:14px; margin-top: 0px; 
      padding-top: 0px; font-weight: normal}
      h1  { margin-bottom: 3px}
       
  </style>
  
  
</head>
<body >

  
<div id="obalovaci">

<!-- POZAD� STR�NKY  -->                
<div id="hlavicka"> <img src="Sablona/hlavicka.jpg" alt="hlavicka" title="" width="100%"> </div>
<div id="levysloupec"> <img src="Sablona/levysloupec.jpg" alt="levysloupec" title="" width="100%" height="100%"> </div>
<div id="stred"><img src="Sablona/stred740.jpg" alt="stred" title="" width="100%" height="100%"></div>
<div id="pravysloupec"> <img src="Sablona/pravysloupec.jpg" alt="pravysloupec" title="" width="100%" height="100%"> </div>
<div id="paticka"></div>
<div id="patickapaticky"></div>

                                                              
<!-- MENU -->
<a class="novinky" alt="normal" title="" href="novinky.php">NOVINKY</a>
<a class="uvod" alt="normal" title="" href="uvod.php">O PROJEKTU</a>
<a class="distribuce" alt="normal" title="" href="distribuce.php">DISTRIBUCE</a>
<a class="knihovna" alt="normal" title="" href="knihovna.php">KNIHOVNA</a>
<a class="financovani" alt="normal" title="" href="financovani.php">FINANCE</a>
<a class="kontakt" alt="normal" title="" href="kontakt.php">KONTAKT</a>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-41695712-1', 'dharmazdarma.cz');
  ga('send', 'pageview');

</script>


<!-- BO�N� MENU -->  
  <a class="kontaktbocni" alt="normal" title="" >KONTAKT</a>
  <a class="kontakt-napiste" alt="normal" title="" href="kontakt.php">Napi�te n�m</a>
  <a class="kontakt-odkazy" alt="normal" title="" href="kontakt-odkazy.php">Odkazy-Dhamma</a>
  <a class="kontakt-odkazy-ruzne" alt="normal" title="" href="kontakt-odkazy-ruzne.php">Odkazy-r�zn�</a>


      <!-- TEXT -->
    
<div id="stred">

              <h1>Kontakt</h1>  <h3> Odkazy - r�zn� </h3>  
               <div class="text" style="text-align: center" >
              

            <h2>Nen�siln� komunikace</h2>
            <a href="http://www.nenasilnakomunikace.com/uvod">www.nenasilnakomunikace.com</a> <br>
            <a href="http://www.zirafistopy.cz">www.zirafistopy.cz</a> <br>
              <a href="http://www.kurzweilova.cz">www.kurzweilova.cz</a> <br>
              <a href="http://www.zdejsoulvi.cz">www.zdejsoulvi.cz</a> <br>
       
                          

            <br><br>
            
            

</div>
    
<!-- TEXT V PATI�CE-->    
<p class="textpaticka">  Copyright 2011 Dharma Zdarma - v�echna pr�va vyhrazena. Vytvo�eno pomoc�
<a href="http://www.jakpsatweb.cz"/> Jak psat web.</a>
<a href="http://www.toplist.cz/" target="_top">
<img src="http://toplist.cz/dot.asp?id=1205275" border="0" width="1" height="1"/></a>
<a href="statistiky.html">Statistiky.</a><br>
Vytvo�il Dalibor Pavl�k. Design <a class="odkazypaticka" href="http://www.martinatothova.com/">Martina T�thov�</a> 
<a class="odkazypaticka" href="http://www.to08.net/">to08.net</a>.</p>

 <!-- FACEBOOK BUTTON-->                                    
<iframe class="likebutton" src="http://www.facebook.com/plugins/like.php?app_id=170821559652007&amp;
href=http%3A%2F%2Fwww.dharmazdarma.cz%2F&amp;send=false&amp;layout=standard&amp;
width=450&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font=verdana&amp;height=35"
scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:21px;" 
allowTransparency="true"></iframe>

<!-- BlueBoard.cz Pocitadlo -->
<span class="blueboard"  ><a href="http://blueboard.cz"></a></span>
<script type="text/javascript" src="http://blueboard.cz/counter_1.php?jid=8ovnmx9ovr4o9rfob57ae7c3tekmci"></script>
<!-- BlueBoard.cz Pocitadlo KONEC --> 


</div>

</body>
</html>
