<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>
<head>
  <meta charset="utf-8" />
<meta http-equiv="Content-type" content="text/html; charset=windows-1250">
    <title>Knihovna, Buddhismus zdarma</title>
<meta name="description" content="Nakladatelstv� Dharma Zdarma: vyd�v�me a distribujeme knihy o Buddhov� u�en� zdarma.">
<meta name="keywords" content="Buddhismus, Knihy, zdarma">
<link rel="stylesheet" type="text/css" href="style-main.css"> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
  <style>
      
      a.knihovna {color: white; font-weight: bold}
      a.knihovna:hover  {background-position: 0px}
      
      a.knihovnabocni { top: 130px; left: 0px; background-image: none; width:120px;
                      font-weight: bold; color: white; }
      a.prednipolicka  { top: 150px; left: 0px; background-image: none; width:120px; font-size: 13px}
      a.zadnipolicka  { top: 170px; left: 0px; background-image: none; width:120px; font-size: 13px}
      a.umeni  { top: 190px; left: 0px; background-image: none; width:120px; font-size: 13px}

      
      h3 {text-decoration: overline; text-align: center; font-size:14px; margin-top: 0px; 
      padding-top: 0px; font-weight: normal}
      h1  { margin-bottom: 3px}
      
      .ikona-dobre-otazky { position: absolute; top: 204px; left: 670px; height: 21px; width: 27px; background-image: url(Guestbooks/Ikony/desature.png); background-position: 0px; }
      .ikona-dobre-otazky:hover {background-image: url(Guestbooks/Ikony/desature.png); background-position: 30px; }
      .ikona-o-pricinach-stesti { position: absolute; top: 228px; left: 508px; height: 21px; width: 27px; background-image: url(Guestbooks/Ikony/desature.png); background-position: 0px; }
      .ikona-o-pricinach-stesti:hover {background-image: url(Guestbooks/Ikony/desature.png); background-position: 30px; }
      .ikona-jak-utisit-vulkany { position: absolute; top: 332px; left: 533px; height: 21px; width: 27px; background-image: url(Guestbooks/Ikony/desature.png); background-position: 0px; }
      .ikona-jak-utisit-vulkany:hover {background-image: url(Guestbooks/Ikony/desature.png); background-position: 30px; }
      .ikona-nedivej-se-povysene { position: absolute; top: 352px; left: 630px; height: 21px; width: 27px; background-image: url(Guestbooks/Ikony/desature.png); background-position: 0px; }
      .ikona-nedivej-se-povysene:hover {background-image: url(Guestbooks/Ikony/desature.png); background-position: 30px; }

      
      
      #levysloupec { height: 641px}
      #stred {height: 616px; top: 93px}
      #pravysloupec {height: 641px}
      #paticka {top: 709px}
      #patickapaticky {top: 732px; height: 2px}
      .textpaticka  {top: 630px; #top: 640px}
      .likebutton {top: 681px}

      a.google-disk{border-bottom: 2px dashed green}

      a.google-disk:hover {border-bottom: 3px dashed white; text-decoration:none}

      
     
       
  </style>
  
  
</head>
<body >

  
<div id="obalovaci">

  <!-- POZAD� STR�NKY  -->                
<div id="hlavicka"> <img src="Sablona/hlavicka.jpg" alt="hlavicka" title="" width="100%"> </div>
<div id="levysloupec"> <img src="Sablona/levysloupec.jpg" alt="levysloupec" title="" width="100%" height="100%"> </div>
<div id="stred"><img src="Sablona/stred740.jpg" alt="stred" title="" width="100%" height="100%"></div>
<div id="pravysloupec"> <img src="Sablona/pravysloupec.jpg" alt="pravysloupec" title="" width="100%" height="100%"> </div>
<div id="paticka"></div>
<div id="patickapaticky"></div>
                                                              
<!-- HLAVN� MENU -->
<a class="novinky" alt="normal" title="" href="novinky.php">NOVINKY</a>
<a class="uvod" alt="normal" title="" href="uvod.php">O PROJEKTU</a>
<a class="distribuce" alt="normal" title="" href="distribuce.php">DISTRIBUCE</a>
<a class="knihovna" alt="normal" title="" href="knihovna.php">KNIHOVNA</a>
<a class="financovani" alt="normal" title="" href="financovani.php">FINANCE</a>
<a class="kontakt" alt="normal" title="" href="kontakt.php">KONTAKT</a>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-41695712-1', 'dharmazdarma.cz');
  ga('send', 'pageview');

</script>





 
     
                                                                              

  <!-- ST�ED -->
      
    
  <div id="stred" >               
              
         
              <h1>Knihovna</h1> <br><br>
              <div class="text">                                                                                                           
               Všechny knihy a texty si lze stáhnout na google disku, který je veřejně
               přístupný.<br><br>

               <a href="https://drive.google.com/drive/folders/1kcJlD7SzhPEEIxY2xD_4FIorSUs7EsLR"
               class="google-disk">GOOGLE DISK DHARMAZDARMA</a>

              
             </div>
             
       
    
              
<!-- TEXT V PATI�CE-->    
<p class="textpaticka">  Copyright 2011 Dharma Zdarma - v�echna pr�va vyhrazena. Vytvo�eno pomoc�
<a href="http://www.jakpsatweb.cz"/> Jak psat web.</a>
<a href="http://www.toplist.cz/" target="_top">
<img src="http://toplist.cz/dot.asp?id=1205275" border="0" width="1" height="1"/></a>
<a href="statistiky.php"></a><br>
Vytvořil Dalibor Pavlík. Design <a class="odkazypaticka" href="http://www.martinatothova.com/">Martina T�thov�</a> 
<a class="odkazypaticka" href="http://www.to08.net/">to08.net</a>.</p>

 <!-- FACEBOOK BUTTON-->                                    
<iframe class="likebutton" src="http://www.facebook.com/plugins/like.php?app_id=170821559652007&amp;
href=http%3A%2F%2Fwww.dharmazdarma.cz%2F&amp;send=false&amp;layout=standard&amp;
width=450&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font=verdana&amp;height=35"
scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:21px;" 
allowTransparency="true"></iframe>

<!-- BlueBoard.cz Pocitadlo -->
<span class="blueboard"  ><a href="http://blueboard.cz"></a></span>
<script type="text/javascript" src="http://blueboard.cz/counter_1.php?jid=8ovnmx9ovr4o9rfob57ae7c3tekmci"></script>
<!-- BlueBoard.cz Pocitadlo KONEC -->


</div>

</body>
</html>
